package id.my.glitchmc.cmdalias;

import dev.jorel.commandapi.CommandAPI;
import dev.jorel.commandapi.CommandAPICommand;
import dev.jorel.commandapi.arguments.GreedyStringArgument;
import dev.jorel.commandapi.arguments.StringArgument;
import dev.jorel.commandapi.executors.CommandArguments;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class CmdAliasPlugin extends JavaPlugin {

    private final Map<String, String> aliases = new LinkedHashMap<>();
    private File aliasesFile;
    private YamlConfiguration aliasesConfig;

    @Override
    public void onEnable() {

        // Siapin file aliases.yml
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        aliasesFile = new File(getDataFolder(), "aliases.yml");
        if (!aliasesFile.exists()) {
            try { aliasesFile.createNewFile(); }
            catch (IOException e) { getLogger().severe("Gagal bikin aliases.yml: " + e.getMessage()); }
        }
        aliasesConfig = YamlConfiguration.loadConfiguration(aliasesFile);

        // Load alias yang udah tersimpan
        if (aliasesConfig.isConfigurationSection("aliases")) {
            for (String key : aliasesConfig.getConfigurationSection("aliases").getKeys(false)) {
                String target = aliasesConfig.getString("aliases." + key);
                if (target != null) {
                    aliases.put(key, target);
                    registerAliasCommand(key, target);
                }
            }
        }

        // Daftarin command /cmdalias
        new CommandAPICommand("cmdalias")
            .withPermission("cmdalias.admin")
            .withSubcommand(
                new CommandAPICommand("add")
                    .withArguments(new StringArgument("alias"))
                    .withArguments(new GreedyStringArgument("target"))
                    .executes((sender, args) -> {
                        String aliasName = ((String) args.get("alias")).toLowerCase();
                        String target = (String) args.get("target");
                        if (aliases.containsKey(aliasName)) {
                            sender.sendMessage("§eAlias §f/" + aliasName + " §esudah ada, menimpa yang lama...");
                            unregisterAliasCommand(aliasName);
                        }
                        aliases.put(aliasName, target);
                        registerAliasCommand(aliasName, target);
                        aliasesConfig.set("aliases." + aliasName, target);
                        saveAliases();
                        sender.sendMessage("§aAlias §f/" + aliasName + " §a-> §f/" + target + " §aberhasil ditambahin!");
                    })
            )
            .withSubcommand(
                new CommandAPICommand("remove")
                    .withArguments(new StringArgument("alias"))
                    .executes((sender, args) -> {
                        String aliasName = ((String) args.get("alias")).toLowerCase();
                        if (!aliases.containsKey(aliasName)) {
                            sender.sendMessage("§cAlias §f/" + aliasName + " §cgak ketemu.");
                            return;
                        }
                        unregisterAliasCommand(aliasName);
                        aliases.remove(aliasName);
                        aliasesConfig.set("aliases." + aliasName, null);
                        saveAliases();
                        sender.sendMessage("§aAlias §f/" + aliasName + " §aberhasil dihapus.");
                    })
            )
            .withSubcommand(
                new CommandAPICommand("list")
                    .executes((sender, args) -> {
                        if (aliases.isEmpty()) {
                            sender.sendMessage("§7Belum ada alias yang dibuat.");
                            return;
                        }
                        sender.sendMessage("§7=== Daftar Alias ===");
                        aliases.forEach((k, v) -> sender.sendMessage("§b/" + k + " §7-> §f/" + v));
                    })
            )
            .register(this);

        getLogger().info("CmdAlias enabled, " + aliases.size() + " alias dimuat.");
    }

    @Override
    public void onDisable() {
        // CommandAPI dikelola sendiri sebagai plugin, gak perlu manual disable
    }

    private void registerAliasCommand(String name, String target) {
        new CommandAPICommand(name)
            .withOptionalArguments(new GreedyStringArgument("args"))
            .executes((sender, args) -> {
                String extraArgs = (String) args.getOptional("args").orElse("");
                String full = target + (extraArgs.isEmpty() ? "" : " " + extraArgs);
                Bukkit.dispatchCommand(sender, full);
            })
            .register(this);
        refreshPlayers();
    }

    private void unregisterAliasCommand(String name) {
        CommandAPI.unregister(name);
        refreshPlayers();
    }

    private void refreshPlayers() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.updateCommands();
        }
    }

    private void saveAliases() {
        try { aliasesConfig.save(aliasesFile); }
        catch (IOException e) { getLogger().severe("Gagal nyimpen aliases.yml: " + e.getMessage()); }
    }
}
